.First.lib = function (...) mecdf.theme ("emerald")

